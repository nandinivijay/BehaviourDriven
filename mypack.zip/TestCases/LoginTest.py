from selenium import webdriver
import unittest
import HtmlTestRunner
import time
import sys    # we need to add the project path to sys path as we have to run the file from command promt
sys.path.append("C:/Users/Sush/PycharmProjects/PythonUnittestProject_POMBased")
from PageObjects.LoginPage import LoginPage

class LoginTest(unittest.TestCase):
    baseURL = "https://admin-demo.nopcommerce.com/"
    username = "admin@yourstore.com"
    password = "admin"
    driver = webdriver.Chrome(executable_path=r"C:\Users\Sush\PycharmProjects\PythonUnittestProject_POMBased\Drivers\chromedriver.exe")

    @classmethod
    def setUpClass(cls):
        cls.driver.get(cls.baseURL)
        cls.driver.maximize_window()

    def test_login(self):
        lp = LoginPage(self.driver)
        lp.setUserName(self.username)
        lp.setPassword(self.password)
        lp.clickLogin()
        time.sleep(5)
        self.assertEqual("Dashboard / nopCommerce administration",self.driver.title,"Web page title is not matched")

    @classmethod
    def tearDownClass(cls):
        cls.driver.close()

if __name__ == '__main__':
    unittest.main()
    #unittest.main(testRunner=HtmlTestRunner.HTMLTestRunner(output=r"C:\Users\Sush\PycharmProjects\PythonUnittestProject_POMBased\Reports"))




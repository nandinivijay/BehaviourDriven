import pytest

@pytest.yield_fixture()
def setup():
    print("Opening URL to login")
    yield
    print("closing browser after login")


def test_SignupbyFacebook(setup):
    print("This is Signup  facebbok")


def test_Signbyemail(setup):
    print("This is Signup by email")
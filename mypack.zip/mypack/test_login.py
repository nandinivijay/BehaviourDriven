import pytest

@pytest.yield_fixture()
def setup():
    print("Opening URL to login")
    yield
    print("closing browser after login")


def test_loginbyFacebook(setup):
    print("This is login by facebbok")


def test_loginbyemail(setup):
    print("This is login by email")
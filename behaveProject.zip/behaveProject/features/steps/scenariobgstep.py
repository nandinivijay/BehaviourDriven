from behave import *

@given(u'I launch  browser')
def step_impl(context):
    assert True,"Test Passed"


@when(u'I open application')
def step_impl(context):
    assert True, "Test Passed"


@when(u'Enter valid cerdicials')
def step_impl(context):
    assert True, "Test Passed"

@when(u'click on login button to login')
def step_impl(context):
    assert True, "Test Passed"

@then(u'User successfully login into dashboard page')
def step_impl(context):
    assert True, "Test Passed"


@when(u'navigate to search page')
def step_impl(context):
    assert True, "Test Passed"


@then(u'Search page should displayed')
def step_impl(context):
    assert True,"Test Passed"


@when(u'navigate to advance search page')
def step_impl(context):
    assert True, "Test Passed"


@then(u'advance search page should displayed')
def step_impl(context):
    assert True,"Test Passed"


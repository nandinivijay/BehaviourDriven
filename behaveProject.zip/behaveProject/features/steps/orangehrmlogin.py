from behave import *
from selenium import webdriver

@given('I launch chrome browser')
def launchbrowser(context):
    context.driver = webdriver.Chrome(executable_path=r"C:\Users\Sush\PycharmProjects\PythonUnittestProject_POMBased\Drivers\chromedriver.exe")


@when('I open Orange HRM homepage')
def openorangehrm(context):
    context.driver.get("https://opensource-demo.orangehrmlive.com/")


@when('Enter username "{user}" and password "{pwd}"')
def enteruserpassword(context,user,pwd):
    context.driver.find_element_by_id('txtUsername').send_keys(user)
    context.driver.find_element_by_id('txtPassword').send_keys(pwd)


@when('click on login button')
def clicklogin(context):
    context.driver.find_element_by_id('btnLogin').click()

@then('User must be successfully login into dashboard page')
def CheckDahboard(context):
    try:
        text = context.driver.find_element_by_xpath("//*[@id='content']/div/div[1]/h1").text
    except:
        context.driver.close()
        assert False,"Test Failed"

    if text == "Dashboard":
        context.driver.close()
        assert True,"Test Passed"

@given(u'I am on the new user registration page')
def step_impl(context):
    context.driver.get("https://opensource-demo.orangehrmlive.com/")



@when(u'I enter valid  data  on the page')
def step_impl(context,DataTable table):
    context.driver.find_element_by_id('txtUsername').send_keys(user)
    context.driver.find_element_by_id('txtPassword').send_keys(pwd)



@then(u'I should see a successful message')
def step_impl(context):
    context.driver.find_element_by_id('btnLogin').click()


@then(u'I quit the broswer')
def step_impl(context):
    context.driver.quit()


